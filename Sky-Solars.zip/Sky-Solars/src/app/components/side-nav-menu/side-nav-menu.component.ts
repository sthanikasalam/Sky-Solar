import { Component, OnInit, signal, Signal } from '@angular/core';
import { MatListModule } from '@angular/material/list';
import { MatSidenavModule } from '@angular/material/sidenav';
import { DashboardService } from '../../services/dashboard.service';
import { CommonModule } from '@angular/common';
import { TablerIconsModule } from 'angular-tabler-icons';
import { IconsModule } from '../icons-module/icons.module';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-side-nav-menu',
  standalone: true,
  imports: [MatSidenavModule, MatListModule, CommonModule, IconsModule, TablerIconsModule, MatIconModule],
  templateUrl: './side-nav-menu.component.html',
  styleUrl: './side-nav-menu.component.scss',
  providers: [DashboardService]
})
export class SideNavMenuComponent implements OnInit {
  sideMenuList: any = {};
  selectedMenu = signal<string>('mainDashboard');
  constructor(private dashboardService: DashboardService) {

  }

  ngOnInit(): void {
    this.getSideNavMenuList();
  }

  handleClick(menu: any) {
    this.selectedMenu.set(menu.key);
  }

  private getSideNavMenuList() {
    this.dashboardService.getSideNavMenus().subscribe({
      next: (data: any) => {
        this.sideMenuList = data.sideNavMenu;
      },
      error: (err) => {
        console.error('Error loading data', err);
        this.sideMenuList = {};
      }
    });
  }

}
