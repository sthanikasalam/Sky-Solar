import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FeatherModule } from 'angular-feather';
import { Camera, Heart, Github, MessageSquare, Bell, DollarSign, ShoppingBag } from 'angular-feather/icons';

const icons= {
  MessageSquare,
  Bell,
  DollarSign,
  ShoppingBag
}

@NgModule({
  declarations: [],
  imports: [
    FeatherModule.pick(icons)
  ],
  exports: [
    FeatherModule
  ]
})
export class FeatherIconsModule { }
