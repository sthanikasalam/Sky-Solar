import { Component, signal } from '@angular/core';
import { HeaderService } from '../../core/services/header.service';

@Component({
  selector: 'app-branding',
  standalone: true,
  imports: [],
  templateUrl: './branding.component.html',
  styleUrl: './branding.component.scss'
})
export class BrandingComponent {
  isSideNavMinimize = signal<boolean>(false);
  constructor(private headerService:HeaderService){ 
    this.headerService.getIsSideNavMinimize().subscribe((res:boolean)=>{
      this.isSideNavMinimize.set(res);
    })
  }
}
