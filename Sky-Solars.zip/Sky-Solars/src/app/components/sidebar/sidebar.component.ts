import { Component, EventEmitter, Output, signal } from '@angular/core';
import { MatNativeDateModule } from '@angular/material/core';
import { BrandingComponent } from '../branding/branding.component';
import { IconsModule } from '../icons-module/icons.module';
import { SettingService } from '../../shared/services/settings.service';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [MatNativeDateModule, BrandingComponent, IconsModule],
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.scss'
})
export class SidebarComponent {
  @Output() closeSideNav= new EventEmitter<void>();
  isMobileView = signal<boolean>(false);

  constructor(private settingService: SettingService) {
    this.settingService.getMobileView().subscribe((res: boolean) => {
      this.isMobileView.set(res);
    })
  }

  closeParentSideNav() {
    this.closeSideNav.emit();
  }

}
