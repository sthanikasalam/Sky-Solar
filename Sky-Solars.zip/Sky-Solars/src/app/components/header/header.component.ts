import { Component, EventEmitter, Output, signal } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { IconsModule } from '../icons-module/icons.module';
import { TablerIconsModule } from 'angular-tabler-icons';
import { MatMenuModule } from '@angular/material/menu';
import { FeatherIconsModule } from '../feather/feather-icons.module';
import { HeaderService } from '../../core/services/header.service';
import { SettingService } from '../../shared/services/settings.service';
import { OverlayModule } from '@angular/cdk/overlay';


@Component({
  selector: 'app-header',
  standalone: true,
  imports: [MatToolbarModule, MatButtonModule, MatIconModule, IconsModule, TablerIconsModule, MatMenuModule, FeatherIconsModule, OverlayModule],
  templateUrl: './header.component.html',
  styleUrl: './header.component.scss',
  // providers:[HeaderService]
})
export class HeaderComponent {
  @Output() openSideNav = new EventEmitter<void>();
  @Output() closeSideNav = new EventEmitter<void>();
  isOpen = signal<boolean>(false);
  private isMobileView: boolean = false;
  constructor(private headerService: HeaderService, private SettingService: SettingService) {
    this.SettingService.getMobileView().subscribe((res: boolean) => {
      if(res == true){
        this.closeSideNav.emit();
      }
      else
      {
        this.openSideNav.emit();
      }
      this.isMobileView = res;
    })
  }

  isSideNavMinimize(): void {
    if (this.isMobileView) {
      this.openParentSideNav();
    }
    else {
      this.headerService.setIsSideNavMinimize();
    }
  }

  openParentSideNav() {
    this.openSideNav.emit();
  }

  onClickOverlay(){
    this.isOpen.set(!this.isOpen())
  }

}
