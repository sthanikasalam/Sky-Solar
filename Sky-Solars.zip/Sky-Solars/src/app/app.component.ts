import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { SettingService } from './shared/services/settings.service';
import { HeaderService } from './core/services/header.service';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent {
  isMobile: boolean = false;
  constructor(private breakpointObserver: BreakpointObserver, private settingService: SettingService, private headerService: HeaderService) {
    this.breakpointObserver.observe([Breakpoints.XSmall, Breakpoints.Small])
      .subscribe(result => {
        this.settingService.setMobileView(result.matches);        
      });
  }
}
