import { Component } from '@angular/core';

@Component({
  selector: 'app-inquiry-dashboard',
  standalone: true,
  imports: [],
  templateUrl: './inquiry-dashboard.component.html',
  styleUrl: './inquiry-dashboard.component.scss'
})
export class InquiryDashboardComponent {

}
