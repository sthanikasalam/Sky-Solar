import { Component, OnInit } from '@angular/core';
import { WelcomeCardComponent } from './welcome-card/welcome-card.component';
import { MatCardModule } from '@angular/material/card';
import { FeatherIconsModule } from '../../../components/feather/feather-icons.module';
import { SalesOverviewComponent } from './sales-overview/sales-overview.component';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { DashboardService } from '../../../services/dashboard.service';
import { TaskSummaryComponent } from './task-summary/task-summary.component';
import { EmloyeeSummaryComponent } from './emloyee-summary/emloyee-summary.component';
import { CustomerManagementComponent } from './customer-management/customer-management.component';
import { ServiceAnalysticsComponent } from './service-analystics/service-analystics.component';
import { InquiryComplaintsComponent } from './inquiry-complaints/inquiry-complaints.component';
import { ClaimsManagementComponent } from './claims-management/claims-management.component';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [WelcomeCardComponent, MatCardModule, FeatherIconsModule, SalesOverviewComponent, 
    MatButtonModule, MatIconModule, TaskSummaryComponent, EmloyeeSummaryComponent, CustomerManagementComponent,
  ServiceAnalysticsComponent, InquiryComplaintsComponent,ClaimsManagementComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.scss'
})
export class DashboardComponent implements OnInit {
  data:any= {};
  constructor(private dashboardService:DashboardService){}

  ngOnInit(): void {    
    this.dashboardService.getMainDashboard().subscribe({
      next: (res: any) => {
        this.data = res;
      },
      error: (err) => {
        console.error('Error loading data', err);
        this.data = {};
      }
    });
  }

}
