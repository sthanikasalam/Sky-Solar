import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmloyeeSummaryComponent } from './emloyee-summary.component';

describe('EmloyeeSummaryComponent', () => {
  let component: EmloyeeSummaryComponent;
  let fixture: ComponentFixture<EmloyeeSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [EmloyeeSummaryComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(EmloyeeSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
