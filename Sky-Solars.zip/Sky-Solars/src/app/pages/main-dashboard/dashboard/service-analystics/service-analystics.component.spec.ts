import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicAnalysticsComponent } from './service-analystics.component';

describe('ServicAnalysticsComponent', () => {
  let component: ServicAnalysticsComponent;
  let fixture: ComponentFixture<ServicAnalysticsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ServicAnalysticsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ServicAnalysticsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
