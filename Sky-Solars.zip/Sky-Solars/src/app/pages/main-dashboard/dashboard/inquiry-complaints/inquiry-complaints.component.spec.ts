import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InquiryComplaintsComponent } from './inquiry-complaints.component';

describe('InquiryComplaintsComponent', () => {
  let component: InquiryComplaintsComponent;
  let fixture: ComponentFixture<InquiryComplaintsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InquiryComplaintsComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InquiryComplaintsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
