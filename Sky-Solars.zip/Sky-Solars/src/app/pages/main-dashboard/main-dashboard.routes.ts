import { Routes } from "@angular/router";
import { DashboardComponent } from "./dashboard/dashboard.component";
import { EmployeeComponent } from "../employee/employee.component";

export const DashboardRoutes: Routes= [
    {
        path:"",
        component:DashboardComponent
    },
    {
        path:"employee",
        component:EmployeeComponent
    }
    
]
