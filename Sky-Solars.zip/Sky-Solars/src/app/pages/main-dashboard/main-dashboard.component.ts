import { ScrollingModule } from '@angular/cdk/scrolling';
import { Component, signal } from '@angular/core';
import { MatSidenavModule } from '@angular/material/sidenav';
import { SidebarComponent } from '../../components/sidebar/sidebar.component';
import { RouterOutlet } from '@angular/router';
import { HeaderComponent } from '../../components/header/header.component';
import { NgScrollbar } from 'ngx-scrollbar';
import { MatListModule } from '@angular/material/list';
import { HeaderService } from '../../core/services/header.service';
import { SettingService } from '../../shared/services/settings.service';
import { SideNavMenuComponent } from '../../components/side-nav-menu/side-nav-menu.component';

@Component({
  selector: 'app-main-dashboard',
  standalone: true,
  imports: [MatSidenavModule, ScrollingModule, NgScrollbar, SideNavMenuComponent, SidebarComponent, MatListModule, RouterOutlet, HeaderComponent],
  templateUrl: './main-dashboard.component.html',
  styleUrl: './main-dashboard.component.scss'
})
export class MainDashboardComponent {
  isSideNavMinimize = signal<boolean>(false);
  isSideNavOpened = signal<boolean>(true);
  isMobileView =  signal<boolean>(false);
  constructor(private headerService: HeaderService, private settingService: SettingService) {
    this.headerService.getIsSideNavMinimize().subscribe((res: boolean) => {
      this.isSideNavMinimize.set(res);
    });
    this.settingService.getMobileView().subscribe((res: boolean) => {
      this.isMobileView.set(res);
      if (res) {
        this.closeSideNav();
      }
    });
  }

  getSideNavClass():string{
    if(this.isMobileView()){
      return "mainWrapper orange_theme";
    }
    else if (!this.isMobileView() && this.isSideNavMinimize()){
      return "mainWrapper orange_theme sidebarNav-mini";
    }
    else
    {
      return "mainWrapper orange_theme";
    }
  }

  openSideNav() {
    this.isSideNavOpened.set(true);
  }
  closeSideNav() {
    this.isSideNavOpened.set(false);
  }

}
