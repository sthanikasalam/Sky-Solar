import { Component, signal } from '@angular/core';
import { MatSidenavModule } from '@angular/material/sidenav';
import { RouterModule } from '@angular/router';
import { SettingService } from '../../shared/services/settings.service';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';


@Component({
  selector: 'app-authentication',
  standalone: true,
  imports: [MatSidenavModule, RouterModule, CommonModule],
  templateUrl: './authentication.component.html',
  styleUrl: './authentication.component.scss'
})
export class AuthenticationComponent {
  isMobileView = signal(false);
  constructor(private settingService: SettingService) {
    this.settingService.getMobileView().subscribe((res: boolean) => {
      this.isMobileView.set(res);
    })
  }

}
