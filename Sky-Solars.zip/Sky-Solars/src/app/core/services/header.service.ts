import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class HeaderService {
  private isSideNavMinimize = new BehaviorSubject(false);
  constructor() { }

  getIsSideNavMinimize() {
    return this.isSideNavMinimize;
  }

  setIsSideNavMinimize() {
    this.isSideNavMinimize.next(!this.isSideNavMinimize.value);  
  }

  setSideNavClose() {
    this.isSideNavMinimize.next(false);  
  }

  setSideNavOpen() {
    this.isSideNavMinimize.next(true);  
  }
 
}
