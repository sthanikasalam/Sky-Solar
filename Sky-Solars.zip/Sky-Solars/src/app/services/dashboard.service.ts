import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class DashboardService {

    constructor(private http: HttpClient) { }

    getSideNavMenus() {
      return  this.http.get('assets/mockData/side-nav-menu.json');
    }

    getMainDashboard() {
      return  this.http.get('assets/mockData/dashboard.json');
    }

}
