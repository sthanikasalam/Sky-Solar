import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SettingService {
  private isMobileView = new BehaviorSubject<boolean>(true);
  
  constructor() { }

  getMobileView() {
    return this.isMobileView;
  }

  setMobileView(flag:boolean) {
    this.isMobileView.next(flag);
  }
 
}
