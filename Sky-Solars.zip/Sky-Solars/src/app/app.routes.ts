import { Routes } from '@angular/router';
import { authRoutes } from './pages/authentication/authentication.routes';
import { AuthenticationComponent } from './pages/authentication/authentication.component';
import { AuthGuard } from './core/services/auth.guard';
import { DashboardRoutes } from './pages/main-dashboard/main-dashboard.routes';

export const routes: Routes = [
    {
        path: "",
        loadComponent: () => import("./pages/main-dashboard/main-dashboard.component").then((c) => c.MainDashboardComponent),
        children: DashboardRoutes
        // canActivate:[AuthGuard]
    },
    {
        path: "auth",
        component: AuthenticationComponent,
        children: authRoutes
    },
    {
        path: "inquiry",
        loadComponent: () => import("./pages/inquiry-dashboard/inquiry-dashboard.component").then((c) => c.InquiryDashboardComponent),
        canActivate: [AuthGuard]
    }
];

// {
//     path: "auth",
//     loadChildren: () => import("./pages/authentication/authentication.routes").then((r)=> r.authRoutes)
// }, 