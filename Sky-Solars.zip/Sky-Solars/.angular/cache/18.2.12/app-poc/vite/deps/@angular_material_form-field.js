import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations
} from "./chunk-2H5BDGUX.js";
import "./chunk-CTNITTO6.js";
import "./chunk-4CYL2HQY.js";
import "./chunk-5PL3LTWU.js";
import "./chunk-HKOFUEFD.js";
import "./chunk-ULQAZSQV.js";
import "./chunk-QD5RGHR7.js";
import "./chunk-2E7OOGUW.js";
import "./chunk-C3SB7ZRI.js";
import "./chunk-J2C546AB.js";
import "./chunk-Y6VNVYEV.js";
import "./chunk-SBLSF24Q.js";
import "./chunk-3OV72XIM.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError,
  matFormFieldAnimations
};
//# sourceMappingURL=@angular_material_form-field.js.map
